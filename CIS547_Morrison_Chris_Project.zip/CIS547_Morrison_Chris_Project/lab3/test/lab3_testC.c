#include <stdio.h>
#include <string.h>

int main() {
	//This program crashes when input is longer than 256 characters
	//The program is close to chrashing when the input is longer than 230 characters
	//input has been altered to be size 256 for this test

	//Based on the length of the original input to the fuzzer, this program should
	//crash often

	int a = 1;
	int b = 0;
	int c;

	//The compiler appears to be allocating memory in reverse order
	//This one is able to catch 
	char anotherArray[11];
	char input[256];
	
	anotherArray[0] = 'a';
	anotherArray[1] = 'b';
	anotherArray[2] = 'c';
	anotherArray[3] = 'd';
	anotherArray[4] = 'e';
	anotherArray[5] = 'f';
	anotherArray[6] = '\0';
	

	char testArray[] = "abcdef";
	//This will allow program to index way beyond end of input
	//as long as stdin is way beyond the length of 20
	
	//Deliberately setting fgets size limit to be greater than what it would ever be
	//to make fgets mimic gets
	fgets(input, 65536, stdin);
	
	//As long as the input is greater than length 20, the input will overwrite another location in memory
	
	//If input is longer than 20, then the characters within anotherArray will probably be replaced.
	//Remember: C stores variables on the stack in contiguous locations in memory (at least how this one has been constructed)
	printf("I %s \n", input);
	printf("A %s \n", anotherArray);
	printf("T %s \n", testArray);
	
	if (strlen(input) > 50) {
		if (strlen(input) > 60) {
			if (strlen(input) > 70) {
				if (strlen(input) > 80) {
					if (strlen(input) > 90) {
						if (strlen(input) > 100) {
							if (strlen(input) > 110) {
								if (strlen(input) > 120) {
									if (strlen(input) > 130) {
										if (strlen(input) > 140) {
											if (strlen(input) > 150) {
												if (strlen(input) > 160) {
													if (strlen(input) > 170) {
														if (strlen(input) > 180) {
															if (strlen(input) > 190) {
																if (strlen(input) > 200) {
																	if (strlen(input) > 210) {
																		if (strlen(input) > 220) {
																			if (strlen(input) > 230) {
																				if (strlen(input) > 240) {
																					for (int i = 0; i < sizeof testArray; i++) {
																						printf("anotherArray %c testArray %c \n", anotherArray[i], testArray[i]);
																						if ( anotherArray[i] != testArray[i]) {
																							//We have a case where input was indexed out of bounds
																							//So we force a divide by 0 error
																							c = a / b;
																						}
																					}
																				}
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}	
}