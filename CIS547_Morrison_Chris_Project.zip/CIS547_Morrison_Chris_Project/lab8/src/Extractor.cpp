#include "Extractor.h"

#include "llvm/IR/Instruction.h"

void Extractor::addDef(const InstMapTy &InstMap, Value *X, Instruction *L) {
  if (InstMap.find(X) == InstMap.end())
    return;
  DefFile << toString(X) << "\t" << toString(L) << "\n";
}

void Extractor::addUse(const InstMapTy &InstMap, Value *X, Instruction *L) {
  if (Constant *C = dyn_cast<Constant>(X))
    return;
  if (InstMap.find(X) == InstMap.end())
    return;
  UseFile << toString(X) << "\t" << toString(L) << "\n";
}

void Extractor::addDiv(const InstMapTy &InstMap, Value *X, Instruction *L) {
  if (Constant *C = dyn_cast<Constant>(X))
    return;
  if (InstMap.find(X) == InstMap.end())
    return;
  DivFile << toString(X) << "\t" << toString(L) << "\n";
}

void Extractor::addTaint(const InstMapTy &InstMap, Instruction *L) {
  TaintFile << toString(L) << "\n";
}

void Extractor::addSanitizer(const InstMapTy &InstMap, Instruction *L) {
  SanitizerFile << toString(L) << "\n";
}

void Extractor::addNext(const InstMapTy &InstMap, Instruction *X,
                        Instruction *Y) {
  NextFile << toString(X) << "\t" << toString(Y) << "\n";
};

/**
 * Extracting facts for alloc, getElementptr, and store instructions to be used for index out of bounds error detection
 * 
 *
 * @brief Collects Datalog facts for each instruction to corresponding facts
 * file.
 */
void Extractor::extractConstraints(const InstMapTy &InstMap, Instruction *I) {
  /**
   * TODO: For each predecessor P of instruction I,
   *       add a new fact in the `next` relation.
   */

//-void DivZeroAnalysis::flowIn(Instruction *Inst, Memory *InMem) {
//-  auto Temp = new Memory(*InMem);
//-  for (auto Pred : getPredecessors(Inst)) {
//-   Temp = join(Temp, OutMap[Pred]);
//-
//-  for (auto Item : *Temp) {
//-    (*InMem)[Item.first] = Item.second;
//-  }
//-}

//- void Extractor::addNext(const InstMapTy &InstMap, Instruction *X,
//-                        Instruction *Y) {
//-  NextFile << toString(X) << "\t" << toString(Y) << "\n";

	for (auto Pred : getPredecessors(I)) {
		if( Pred != nullptr ){
			addNext( InstMap, Pred, I );
		}
	}

  /**
   * TODO:
   *
   *   For each of the instruction add appropriate facts:
   *     Add `def` and `use` relations.
   *   For `BinaryOperator` instructions involving division:
   *     Add a fact for the `div` relation.
   *   For `CallInst` instructions:
   *     Add a `def` relation only if it returns a non-void value.
   *     If its a call to tainted input,
   *       Add appropriate fact to `taint` relation.
   *     If its a call to sanitize,
   *       Add appropriate fact to `sanitizer` relation.
   *
   * NOTE: Many Values may be used in a single instruction,
   *       but at most one Value can be defined in one instruction.
   * NOTE: You can use `isTaintedInput()` and `isSanitizer()` function
   *       to check if a particular CallInst is a tainted input
   *       or sanitize respectively.
   */

  static std::string ArrType;
  static std::string ArrIndx;
  static std::string ArrName;
  static int ArrSize;
  static int ArrOffs;
  static std::map<std::string,int> ArrList;



  if (AllocaInst *AI = dyn_cast<AllocaInst>(I)) {
    // do nothing, alloca is just a declaration.
	// now we are looking at Alloca to see if we can find the arrays ...
	// Op 0 is the src, the instruction itslef is the dst.
	errs() << "\n- Alloca Instruction " << toString(AI) << "\n";
	errs() << "   Type " << *(AI->getType()) << "\n";
	errs() << "   AllocatedType " << *(AI->getAllocatedType()) << "\n";
	errs() << "   ArraySize " << *(AI->getArraySize()) << "\n";
	errs() << "   ArraySize " << (AI->getAllocatedType()->getArrayNumElements()) << "\n";

	ArrName = toString(AI);
	ArrSize = (AI->getAllocatedType()->getArrayNumElements());
	errs() << ". ArrList " << ArrName << " " << ArrSize << "\n";
	ArrList.insert({ArrName, ArrSize});

	//errs() << "TypeAllocSize "<< AI->getTypeAllocSize() << "\n";
	//addDef(InstMap, AI, AI);
	
	//initially only handle one array in a source file.  Can expand this using vectors
	//to store multiples and loop through them
	
  } else if (Instruction *GEP = dyn_cast<GetElementPtrInst>(I)) {
    // TODO: Extract facts from CmpInst
	
	errs() << "\n- GetElementPtrInst " << toString(GEP) << "\n";
	errs() << "   Op 0 " << toString(GEP->getOperand(0)) << "\n";
	errs() << "   Op 1 " << toString(GEP->getOperand(1)) << "\n";
	errs() << "   Op 2 " << toString(GEP->getOperand(2)) << "\n";

	ArrIndx = toString(GEP);
	ArrName = toString(GEP->getOperand(0));
	std::string Op2 = toString(GEP->getOperand(2));
	ArrOffs = stoi( Op2.substr( Op2.find(" ")+1) );

	errs() <<". ArrName " << ArrName << " " << ArrIndx << " " << ArrOffs << "\n";

  } else if (StoreInst *SI = dyn_cast<StoreInst>(I)) {
    // TODO: Extract facts from StoreInst
	
	errs() << "\n- Store Instruction " << toString(SI) << "\n";
	errs() << "   Op 0 " << toString(SI->getOperand(0)) << "\n";
	errs() << "   Op 1 " << toString(SI->getOperand(1)) << "\n";

	ArrIndx = toString(SI->getOperand(1));

	//for ( auto itr = ArrList.begin(); itr != ArrList.end(); ++itr ) {
	//	errs() << itr->first << " " << itr->second << "\n";
	//}

	int ArrMax = ArrList[ArrName];
	errs() << ". Store " << ArrName << " " << ArrIndx << " " << ArrOffs <<  " " << ArrMax << "\n";

	//Now for the final check and print an error message
	if ( ArrOffs >= ArrMax ) {
		errs() << "ERROR: Index Out of bounds. " << ArrName << " " << ArrIndx << "\n";
	}
	// The instruction itself is the src, Op 0 is the dst
	// Store uses a Def %x and a Use %y   *%x = %y 
	//auto *X = SI->getOperand(0);
	//addDef(InstMap, SI, SI);	
	//addUse(InstMap, X, SI);


	
  }	else if (LoadInst *LI = dyn_cast<LoadInst>(I)) {
    // TODO: Extract facts from LoadInst

	errs() << "\nLoad Instruction " << toString(LI) << "\n";
	// Op 0 is the src, the instruction itslef is the dst.
	// Load uses a Def %x and a Use %y   %x = *%y 
	//auto *X = LI->getOperand(0));
	//addDef(InstMap, LI, LI);	
	//addUse(InstMap, X, LI);
	
  } else if (BinaryOperator *BI = dyn_cast<BinaryOperator>(I)) {
    // TODO: Extract facts from BinaryOperation
	
	errs() << "\nBinop Instruction " << toString(BI) << "\n";
	// Op 0 and Op 1 are the src, the instruction itself is the dst.
	//auto *X = LI->getOperand(0));
	//auto *Y = LI->getOperand(1));	
	//addDef(InstMap, BI, BI);
	//addUse(InstMap, X, BI);
	//addUse(InstMap, Y, BI);	
	
  } else if (CallInst *CI = dyn_cast<CallInst>(I)) {
    // TODO: Extract facts from CallInst
	
	errs() << "\nCall Instruction " << toString(CI) << "\n";
	//Is this a TaintedInput() or Sanitizer()
    //if( isTaintedInput(CI)) {
    //  addTaint(InstMap, CI);
    //} else if ( isSanitizer(CI)) {
    //  addSanitizer(InstMap, CI);
	//}
	//else {
	  //It is a call to something else
	  // Each Op is the src, the instruction itself is the dst.
	  //addDef(InstMap, CI, CI);
	  //for (auto ItOp = I->operands().begin(), End = I->operands().end(); ItOp != End; ++ItOp) {
		//XN = ItOp->get();
		//addUse(InstMap, XN, CI);
	  //}
	//}
	
  } else if (CastInst *CI = dyn_cast<CastInst>(I)) {
    // TODO: Extract facts from CastInst
	
	errs() << "\nCast Instruction " << toString(CI) << "\n";
	// Op 0 is the src, the instruction itslef is the dst.
	// Cast uses a Def %x and a Use %y   %x = (cast) %y 
	//auto *X = CI->getOperand(0));
	//addDef(InstMap, CI, CI);	
	//addUse(InstMap, X, CI);
	
  } else if (CmpInst *CI = dyn_cast<CmpInst>(I)) {
    // TODO: Extract facts from CmpInst
	
	errs() << "\nCmp Instruction " << toString(CI) << "\n";
	// Op 0 and Op 1 are the src, the instruction itself is the dst.
	//auto *X = CI->getOperand(0));
	//auto *Y = CI->getOperand(1));	
	//addDef(InstMap, CI, CI);
	//addUse(InstMap, X, CI);
	//addUse(InstMap, Y, CI);	
	
  }
}
