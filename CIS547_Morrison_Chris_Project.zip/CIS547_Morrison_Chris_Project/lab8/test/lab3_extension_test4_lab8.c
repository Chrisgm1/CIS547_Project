#include <stdio.h>
#include <string.h>

int main() {
	
	//This program crashes when input is longer than 15 characters
	//Remember: A \0 is added onto the bask which is why it crashes at 16 characters
	//1122334455667788 will cause a crash
	//112233445566778 will not cause a crash
	
	//int a = 1;
	//int b = 0;
	//int c;

	//The compiler appears to be allocating memory in reverse order
	int anotherArray[10];
	//Keep in mind: The way that the compiler is set up is that it allocates in 2^x quantities
	//therefore length 20 will end up allocating 32 spots in memory
	//char input[16];
	
	anotherArray[0] = 1;
	anotherArray[1] = 2;
	anotherArray[2] = 3;
	anotherArray[3] = 4;
	anotherArray[4] = 5;
	anotherArray[5] = 6;
	anotherArray[6] = 7;
	anotherArray[7] = 0;
	anotherArray[8] = 0;
	anotherArray[9] = 0;
	anotherArray[10] = 0;
	anotherArray[11] = 0;
	anotherArray[12] = 0;
	anotherArray[13] = 0;
	
	//anotherArray[6] = '\0';

	//int testArray[] = {1, 2, 3, 4, 5, 6};
	//This will allow program to index way beyond end of input
	//as long as stdin is way beyond the length of 20
	//fgets(input, 100, stdin);
	//gets(input);
	
	//If input is longer than 20, then the characters within anotherArray will probably be replaced.
	//Remember: C stores variables on the stack in contiguous locations in memory (at least how this one has been constructed)
	//printf("I %s \n", input);
	//printf("A \n");
	//int size = sizeof anotherArray;
	//printf("%d size \n", size);
	/*
	for (int j = 0; j < (sizeof(anotherArray)/sizeof(anotherArray[0])); j++) {
		printf("%d j %d \n", anotherArray[j], j);
	}
	printf("T \n");
	for (int k = 0; k < (sizeof(testArray)/sizeof(testArray[0])); k++) {
		printf("%d \n", testArray[k]);
	}
	
	printf("%x\n", &input);
	printf("%x\n", &anotherArray);
	*/
	//for (int i = 0; i < (sizeof(testArray)/sizeof(testArray[0])); i++) {
		//printf("anotherArray %d testArray %d \n", anotherArray[i], testArray[i]);
		//if ( anotherArray[i] != testArray[i]) {
			//We have a case where input was indexed out of bounds
			//So we force a divide by 0 error
			//c = a / b;
		//}
	//}
}