#include <stdio.h>
#include <string.h>

int main() {
	
	//This program crashes when input is longer than 15 characters
	//Remember: A \0 is added onto the bask which is why it crashes at 16 characters
	//1122334455667788 will cause a crash
	//112233445566778 will not cause a crash
	
	

	//The compiler appears to be allocating memory in reverse order
	int anotherArray[8];
	//Keep in mind: The way that the compiler is set up is that it allocates in 2^x quantities
	//therefore length 20 will end up allocating 32 spots in memory
	//char input[16];
	
	for (int j = 0; j < 12; j++) {
		anotherArray[j] = j;
	}
	
}