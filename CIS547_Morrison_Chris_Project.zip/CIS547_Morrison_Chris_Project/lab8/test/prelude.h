extern int tainted_input();
extern int untainted_input();
extern int sanitizer(int);
extern int not_sanitizer(int);
